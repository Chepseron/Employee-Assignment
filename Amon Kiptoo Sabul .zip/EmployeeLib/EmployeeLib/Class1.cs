﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Employee
{
    public class Employee
    {

        Dictionary<string, EmployeeObject> EmployeeDictionary = new Dictionary<string, EmployeeObject>();
        LogWriter log = new LogWriter();
        public Employee()
        {
            EmployeeObject emp = new EmployeeObject();


            try
            {
                using (var reader = new StreamReader(@"C:\Employees.csv"))
                {

                    start:
                    while (!reader.EndOfStream)
                    {
                        var line = reader.ReadLine();
                        var values = line.Split(',');
                        emp.EmployeeID = values[0];
                        emp.ManagerID = values[1];
                        emp.EmployeeSalary = Int32.Parse(values[2]);
                        if (EmployeeDictionary.ContainsKey(values[0]))
                        {
                            log.LogWrite(emp.EmployeeID + "Employee already exists and has a manager");
                            Console.Write("Employee already exists and has a manager");
                        }
                        else if (emp.ManagerID.Equals(""))
                        {
                            string uniqueKey = "CEO";


                            if (EmployeeDictionary.ContainsKey(uniqueKey))
                            {
                                log.LogWrite(emp.EmployeeID + "CEO already exists");
                                Console.Write("CEO exists");
                                goto start;
                            }
                            else
                            {
                                EmployeeDictionary.Add(uniqueKey, emp);
                                log.LogWrite(emp.EmployeeID + "Added Successfuly");
                                Console.Write("Added " + emp.EmployeeID);
                            }
                        }
                        else
                        {
                            EmployeeDictionary.Add(emp.EmployeeID, emp);
                            Console.Write("Added " + emp.EmployeeID);
                            log.LogWrite(emp.EmployeeID + "Added Successfuly");
                        }

                        emp = new EmployeeObject();
                    }
                }
            }
            catch (Exception ex)
            {
                log.LogWrite("FATAL ERROR " + ex.Message);
                Console.Write("Error exists" + ex.Message);
            }

        }
        static void Main(string[] args)
        {
            Employee emp = new Employee();
            emp.SalaryBudgetPerManager("Eva");
        }

        public int SalaryBudgetPerManager(string ManagerID)
        {
            int sum = EmployeeDictionary[ManagerID].EmployeeSalary;
            List<EmployeeObject> employees = new List<EmployeeObject>();

            foreach (KeyValuePair<string, EmployeeObject> b in EmployeeDictionary)
            {
                EmployeeObject emp = new EmployeeObject();

                string key = b.Key.ToString();
                emp.ManagerID = EmployeeDictionary[key].ManagerID;
                emp.EmployeeID = EmployeeDictionary[key].EmployeeID;
                emp.EmployeeSalary = EmployeeDictionary[key].EmployeeSalary;
                employees.Add(emp);
                if (emp.ManagerID == ManagerID)
                {
                    sum += emp.EmployeeSalary;

                }


                foreach (EmployeeObject employeeIndividual in employees)
                {
                    if (employeeIndividual.ManagerID == emp.EmployeeID)
                    {

                        SalaryBudgetPerManager(emp.EmployeeID);
                    }
                }
                //bool containsItem = employees.Any(item => item.EmployeeID == ManagerID);
                //if (containsItem == true)
                //{
                //    Console.Write("the employee is a manager");
                //}

            }
            log.LogWrite(ManagerID + " Total salary for employs managed " + sum);
            return sum;
        }


        //private void Traverse(int v, HashSet<int> visited)
        //{
        //    // Mark this node as visited
        //    visited.Add(v);
        //    Console.WriteLine(v);
        //    // Only if the node has a any adj notes
        //    if (EmployeeDictionary.ContainsKey(v))
        //    {
        //        // Iterate through UNVISITED nodes
        //        foreach (int neighbour in EmployeeDictionary[v].Where(a => !visited.Contains(a)))
        //        {
        //            Traverse(neighbour, visited);
        //        }
        //    }
        //}


    }

    class EmployeeObject
    {
        public string EmployeeID { get; set; }

        public string ManagerID { get; set; }

        public int EmployeeSalary { get; set; }
    }


    class LogWriter
    {
        private string m_exePath = string.Empty;
        public void LogWrite(string logMessage)
        {
            m_exePath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
            if (!File.Exists(m_exePath + "\\" + "log.txt"))
                File.Create(m_exePath + "\\" + "log.txt");

            try
            {
                using (StreamWriter w = File.AppendText(m_exePath + "\\" + "log.txt"))
                    AppendLog(logMessage, w);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

        private void AppendLog(string logMessage, TextWriter txtWriter)
        {
            try
            {
                txtWriter.Write("\r\nLog Entry : ");
                txtWriter.WriteLine("{0} {1}", DateTime.Now.ToLongTimeString(), DateTime.Now.ToLongDateString());
                txtWriter.WriteLine("  :");
                txtWriter.WriteLine("  :{0}", logMessage);
                txtWriter.WriteLine("-------------------------------");
            }
            catch (Exception ex)
            {
            }
        }
    }
}
