﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Employee;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee.Tests
{
    [TestClass()]
    public class EmployeeTests
    {
        [TestMethod()]
        public void EmployeeTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void SalaryBudgetPerManagerTest()
        {
            Assert.Fail();
        }
    }
}